+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
The zip file includes:
readme.txt           -----> this file
fingerprint.zip    -----> a .zip file which must be unzipped in Matlab current directory

Type "fpextractdemo" on MATLAB prompt to start fingerprint processing.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++



FPEXTRACTDEMO Fingerprint extracting the features on DEMO API program
    Cheng Long Adam Wang, September 2002
    
    $Revision: 1.0 $  $Date: 2002.10.2  $
    $Revision: 2.0 $  $Date: 2003.11.29 $    by Luigi Rosa
                                             email:   luigi.rosa@tiscali.it 
                                             mobile:  +393403463208
                                             website: http://utenti.lycos.it/matlab
 
Modified in $Revision 2.0$ :
    - new GUI
    - 8 Gabor filters 0 22.5 45 67.5 90 112.5 135 157.5 degree
    - Convolution is performed in frequency domain
    - DataBase
    - Fingerprint matching
    - Error management
 
  Input fingerprint should be 256 x 256 grayscale bmp image
  8-bit grayscale image @ 500 dpi.
  If these conditions are not verified some parameters in m-functions
  should be changed in a proper way.
   
    Options:
      - Centralize:          calculate the center point and the binarized image
      - Crop:                    image cropping
      - Sectorize:           visualize the circular sectors
      - Normalize:          normalize input image
      - Gabor filters:     visualize the Gabor filters
      - Convolute:         compute convolution of input image and Gabor filters
      - Features:            FingerCodes visualization
      - FingerCode:      add the input fingerprint to Database
      - Check:                fingerprint matching
 
 
  A crucial step in fingerprint recognition is center point determination. 
  If any error occurs while cropping image you can use the auxiliary m-file
  "vedicentro.m": it visualizes the input fingerprint and the center point
  calculated by the m-function "centralizing.m"
 
 
    References:
 
    Cheng Long Adam Wang, researcher
    Fingerprint Recognition System
    http://home.kimo.com.tw/carouse9/FRS.htm
 
    A. K. Jain, S. Prabhakar, and S. Pankanti, "A Filterbank-based Representation for 
    Classification and Matching of Fingerprints", International Joint Conference on 
    Neural Networks (IJCNN), pp. 3284-3285, Washington DC, July 10-16, 1999. 
    http://www.cse.msu.edu/~prabhaka/publications.html
 
    "Fingerprint Classification and Matching Using a Filterbank", Salil Prabhakar
    A DISSERTATION Submitted to Michigan State University in partial fulfillment 
    of the requirements for the degree of DOCTOR OF PHILOSOPHY, Computer 
    Science & Engineering, 2001
    http://biometrics.cse.msu.edu/SalilThesis.pdf
 
    Final Report 18-551 (Spring 1999) Fingerprint Recognition Group Number 19
    Markus Adhiwiyogo, Samuel Chong, Joseph Huang, Weechoon Teo
    http://www.ece.cmu.edu/~ee551/Old_projects/projects/s99_19/finalreport.html
 
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
MCGO Matlab Code Generation and Optimization
Luigi Rosa
Via Centrale 35
67042 Civita Di Bagno
L'Aquila --- ITALY

email       luigi.rosa@tiscali.it
mobile    +39 340 3463208

Please contribute if you find this software useful.

Report bugs to luigi.rosa@tiscali.it
+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++